import pyrtl

# Inputs
q_sa       = pyrtl.Input(16, 'q_sa')
reward     = pyrtl.Input(16, 'reward')
q_next_max = pyrtl.Input(16, 'q_next_max')
alpha      = pyrtl.Input(16, 'alpha')
gamma      = pyrtl.Input(16, 'gamma')

# Output
q_updated = pyrtl.Output(16, 'q_updated')

# Use PyRTL shift function
gamma_q_next = pyrtl.shift_right_logical(gamma * q_next_max, 7)
temporal_diff = reward + gamma_q_next - q_sa
scaled_update = pyrtl.shift_right_logical(alpha * temporal_diff, 7)
q_updated <<= q_sa + scaled_update

# Simulation
sim_trace = pyrtl.SimulationTrace()
sim = pyrtl.Simulation(tracer=sim_trace)

inputs = {
    'q_sa': 50,
    'reward': 100,
    'q_next_max': 70,
    'alpha': 20,
    'gamma': 90
}

sim.step(inputs)
sim_trace.render_trace()
