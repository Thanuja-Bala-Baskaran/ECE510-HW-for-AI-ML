import numpy as np
import gymnasium as gym
import pyrtl
import time

# ------------------------------
# Build PyRTL Q-update block
# ------------------------------
def build_q_update_block():
    pyrtl.reset_working_block()

    q_sa       = pyrtl.Input(16, 'q_sa')
    reward     = pyrtl.Input(16, 'reward')
    q_next_max = pyrtl.Input(16, 'q_next_max')
    alpha      = pyrtl.Input(16, 'alpha')
    gamma      = pyrtl.Input(16, 'gamma')
    q_updated  = pyrtl.Output(16, 'q_updated')

    gamma_q_next = pyrtl.shift_right_logical(gamma * q_next_max, 7)
    temporal_diff = reward + gamma_q_next - q_sa
    scaled_update = pyrtl.shift_right_logical(alpha * temporal_diff, 7)
    q_updated <<= q_sa + scaled_update

    return pyrtl.Simulation(tracer=pyrtl.SimulationTrace())

# ------------------------------
# Q-learning with HW block
# ------------------------------
env = gym.make("FrozenLake-v1", is_slippery=False)
n_states = env.observation_space.n
n_actions = env.action_space.n
Q = np.zeros((n_states, n_actions))

alpha = 0.2
gamma = 0.9
epsilon = 0.3  # Increased exploration
episodes = 15000  # More training
reward_sum = 0

sim = build_q_update_block()

start_time = time.time()

for episode in range(episodes):
    state, _ = env.reset()
    done = False

    while not done:
        # Epsilon-greedy action
        if np.random.rand() < epsilon:
            action = env.action_space.sample()
        else:
            action = np.argmax(Q[state])

        next_state, reward, terminated, truncated, _ = env.step(action)
        done = terminated or truncated

        reward_sum += reward

        # Prepare inputs to HW
        vec = {
            'q_sa': int(Q[state, action] * 100),
            'reward': int(reward * 100),
            'q_next_max': int(np.max(Q[next_state]) * 100),
            'alpha': int(alpha * 100),
            'gamma': int(gamma * 100)
        }

        sim.step(vec)
        q_updated = sim.inspect('q_updated') / 100.0
        Q[state, action] = q_updated

        state = next_state

    # Every 1000 episodes, show diagnostics
    if (episode + 1) % 1000 == 0:
        print(f"Episode {episode + 1} | Total reward: {reward_sum:.1f} | Q[0]: {np.round(Q[0], 2)}")
        reward_sum = 0

# Final Q-table
end_time = time.time()
print("\nTraining complete. Final Q-table:")
print(np.round(Q, 2))
print(f"\nTotal training time: {end_time - start_time:.2f} seconds")
