import numpy as np
import gymnasium as gym  # If this doesn't work, change to `import gym`
import time

# Environment setup
env = gym.make("FrozenLake-v1", is_slippery=False)  # Deterministic version
n_states = env.observation_space.n
n_actions = env.action_space.n

# Q-table and hyperparameters
Q = np.zeros((n_states, n_actions))
alpha = 0.1
gamma = 0.99
epsilon = 0.1
n_episodes = 10000

q_time = 0  # For measuring T4

start_time = time.time()  # Start T3

for episode in range(n_episodes):
    state, _ = env.reset()
    done = False

    while not done:
        # Choose action (epsilon-greedy)
        if np.random.rand() < epsilon:
            action = env.action_space.sample()
        else:
            action = np.argmax(Q[state])

        # Take action
        next_state, reward, terminated, truncated, _ = env.step(action)
        done = terminated or truncated

        # Time just the Q-update part (T4)
        q_start = time.time()
        Q[state, action] = Q[state, action] + alpha * (
            reward + gamma * np.max(Q[next_state]) - Q[state, action]
        )
        q_end = time.time()
        q_time += (q_end - q_start)

        state = next_state

end_time = time.time()  # End T3

# Print both T3 and T4
print(f"Total time for Q-learning (T3): {(end_time - start_time)*1000:.2f} ms")
print(f"Total time for Q-update only (T4): {q_time*1000:.2f} ms")
