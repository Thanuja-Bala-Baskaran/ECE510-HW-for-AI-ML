import dis
import collections
from matrix_profiler import matrix_multiply
from quicksort_profiler import quicksort
from cnn_profiler import Net

def count_instructions(func):
    instructions = dis.get_instructions(func)
    counter = collections.Counter(instr.opname for instr in instructions)
    return counter

def display(name, counter):
    print(f"\n{name} Instruction Count:")
    for opname, count in counter.most_common():
        print(f"{opname}: {count}")

if __name__ == "__main__":
    mm_count = count_instructions(matrix_multiply)
    qs_count = count_instructions(quicksort)
    cnn_count = count_instructions(Net.forward)

    display("Matrix Multiplication", mm_count)
    display("Quicksort", qs_count)
    display("CNN Forward", cnn_count)
