import random
import time
import cProfile
import pstats

def quicksort(arr):
    if len(arr) <= 1:
        return arr
    pivot = arr[0]
    less = [x for x in arr[1:] if x <= pivot]
    greater = [x for x in arr[1:] if x > pivot]
    return quicksort(less) + [pivot] + quicksort(greater)

def workload():
    sizes = [500, 1000, 2000]
    for size in sizes:
        arr = [random.randint(1, 10000) for _ in range(size)]
        print(f"\nSorting array of size {size}...")
        start = time.time()
        quicksort(arr)
        end = time.time()
        print(f"Time taken: {end - start:.4f} seconds")

if __name__ == "__main__":
    profiler = cProfile.Profile()
    profiler.enable()
    workload()
    profiler.disable()
    
    print("\n--- CPU Profiling Result ---")
    stats = pstats.Stats(profiler)
    stats.strip_dirs()
    stats.sort_stats("cumtime")
    stats.print_stats(10)
