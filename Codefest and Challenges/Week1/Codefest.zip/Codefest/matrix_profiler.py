import numpy as np
import time
import cProfile
import pstats

def matrix_multiply(n):
    A = np.random.rand(n, n)
    B = np.random.rand(n, n)
    result = np.dot(A, B)
    return result

def workload():
    sizes = [100, 200, 300, 400, 500]
    for size in sizes:
        print(f"\nMultiplying {size}x{size} matrices...")
        start_time = time.time()
        matrix_multiply(size)
        end_time = time.time()
        print(f"Time taken: {end_time - start_time:.4f} seconds")

if __name__ == "__main__":
    print("Starting workload...\n")

    # Start profiling
    profiler = cProfile.Profile()
    profiler.enable()

    # Run matrix workload
    workload()
    
    # Stop profiling
    profiler.disable()

    # Save profiling results to a file for SnakeViz
    profiler.dump_stats("matrix_profile.prof")

    # Optional terminal summary (not needed for SnakeViz but helpful)
    print("\n--- CPU Profiling Result (Top 10 Functions) ---")
    stats = pstats.Stats(profiler)
    stats.strip_dirs()
    stats.sort_stats("cumtime")
    stats.print_stats(10)

    print("\nProfile saved as matrix_profile.prof — run `snakeviz matrix_profile.prof` to visualize.")