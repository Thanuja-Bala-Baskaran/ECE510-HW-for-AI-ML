import dis
from matrix_profiler import matrix_multiply
from quicksort_profiler import quicksort
from cnn_profiler import Net

print("\n--- Matrix Multiply Bytecode ---")
dis.dis(matrix_multiply)

print("\n--- Quicksort Bytecode ---")
dis.dis(quicksort)

print("\n--- CNN Forward Pass Bytecode ---")
dis.dis(Net.forward)
